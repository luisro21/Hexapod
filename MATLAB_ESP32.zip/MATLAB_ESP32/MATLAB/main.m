try
    esp32 = esp32_connect('192.168.50.42');
    disp("Server connected.");
catch
    disp("Error conecting to esp32 server.");
end

m1 = "512";
m2 = "692";
m3 = "412";
m4 = "512";
m5 = "692";
m6 = "412";
m7 = "512";
m8 = "692";
m9 = "412";
m10 = "512";
m11 = "692";
m12 = "412";
m13 = "512";
m14 = "692";
m15 = "412";
m16 = "512";
m17 = "692";
m18 = "412";

buff = "{m1: " + m1 + ", m2: " + m2 + ", m3: " + m3 + ", m4: " + m4 + ", m5: " + m5 + ", m6: " + m6 + ", m7: " + m7 + ", m8: " + m8 + ", m9: " + m9 + ", m10: " + m10 + ", m11: " + m11 + ", m12: " + m12 + ", m13: " + m13 + ", m14: " + m14 + ", m15: " + m15 + ", m16: " + m16 + ", m17: " + m17 + ", m18: " + m18 + "}";

m = read(esp32, 11, "string");
disp(m);

% write(esp32, "(1,2,3,4,5,6)", "string");
write(esp32, buff, "string");

r = read(esp32, 7, "string");
disp(r);

% while(1)
%     try
%         
%         
%     catch
%         disp("No data");
%     end
% end