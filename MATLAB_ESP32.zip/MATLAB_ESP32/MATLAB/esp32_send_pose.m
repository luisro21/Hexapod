%% Send pose to ESP32
% 18 valores 

function esp32_send_pose(tcp_obj, data)

    flush(tcp_obj);
    writeline(tcp_obj, data);
    
%     timeout_count = 0;
%     timeout = 1000;
    %


    %write(tcp_obj, jsonencode(data));
    %f
    
%     while((tcp_obj.NumBytesAvailable == 0) && (timeout_count < timeout))
%         timeout_count = timeout_count + 1;
%     end
%     if(timeout_count == timeout)
%         disp('ERROR: Could not receive data from server.');
%         return;
%     else
%         %mocap_data = jsondecode(char(read(tcp_obj)));
%         mocap_data = char(read(tcp_obj));
% 
%     end
    
end