function esp32_disconnect()

    %write(tcp_obj, uint8('EXIT'));
    clear;
    echotcpip("off")
    disp('Disconnected from ESP32 server.');
    
end